package com.example.customerlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerlistApplicationTests {

	@Test
	void contextLoads() {
	}

}
