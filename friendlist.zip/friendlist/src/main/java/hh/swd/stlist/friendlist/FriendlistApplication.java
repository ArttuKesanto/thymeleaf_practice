package hh.swd.stlist.friendlist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FriendlistApplication {

	public static void main(String[] args) {
		SpringApplication.run(FriendlistApplication.class, args);
	}

}
