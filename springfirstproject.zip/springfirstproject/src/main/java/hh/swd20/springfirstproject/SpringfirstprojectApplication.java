package hh.swd20.springfirstproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringfirstprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringfirstprojectApplication.class, args);
	}

}
