package hh.swd.example20.carprojectexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarprojectexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
