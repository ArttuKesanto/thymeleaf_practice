package hh.swd.hellothyme20.hellothymeleafagename;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellothymeleafagenameApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellothymeleafagenameApplication.class, args);
	}

}
