package hh.swd.stlist.studentlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentlistApplicationTests {

	@Test
	void contextLoads() {
	}

}
