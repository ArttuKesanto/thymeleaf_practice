package hh.swd.stlist.studentlist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentlistApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentlistApplication.class, args);
	}

}
