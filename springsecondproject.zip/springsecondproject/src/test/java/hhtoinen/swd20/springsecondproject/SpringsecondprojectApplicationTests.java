package hhtoinen.swd20.springsecondproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecondprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
